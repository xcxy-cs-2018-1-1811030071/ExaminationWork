/*
 Navicat MongoDB Data Transfer

 Source Server         : MongoDB
 Source Server Type    : MongoDB
 Source Server Version : 40405
 Source Host           : localhost:27017
 Source Schema         : CommunityServer

 Target Server Type    : MongoDB
 Target Server Version : 40405
 File Encoding         : 65001

 Date: 27/04/2021 11:23:25
*/


// ----------------------------
// Collection structure for complain
// ----------------------------
db.getCollection("complain").drop();
db.createCollection("complain");

// ----------------------------
// Documents of complain
// ----------------------------
db.getCollection("complain").insert([ {
    _id: ObjectId("607e7c66b0370000f100444d"),
    UesrName: "张三",
    ServerName: "王五",
    orderID: 10001,
    service: "水电维修",
    Content: "服务态度不好",
    administrator: "易烊",
    Time: "2021/12/21"
} ]);
db.getCollection("complain").insert([ {
    _id: ObjectId("607e7c66b0370000f100444e"),
    UesrName: "张三",
    ServerName: "沈六",
    orderID: 10002,
    service: "家教",
    Content: "教课不认真",
    administrator: "王一",
    Time: "2021/12/22"
} ]);
db.getCollection("complain").insert([ {
    _id: ObjectId("607e7c66b0370000f100444f"),
    UesrName: "张三",
    ServerName: "小小",
    orderID: 10003,
    service: "家教",
    Content: "打骂孩子",
    administrator: "易烊",
    Time: "2021/12/23"
} ]);

// ----------------------------
// Collection structure for platform
// ----------------------------
db.getCollection("platform").drop();
db.createCollection("platform");

// ----------------------------
// Documents of platform
// ----------------------------
db.getCollection("platform").insert([ {
    _id: ObjectId("608782858e250000a60027e0"),
    serveLocation: [
        {
            localID: 10001,
            location: "幸福小区社区服务站",
            Number: 200,
            administrator: [
                {
                    adName: "易烊",
                    adId: 110001,
                    password: 12333,
                    department: "财政部",
                    postion: "部长"
                },
                {
                    adName: "网元",
                    adId: 110001,
                    password: 12333,
                    department: "后勤部",
                    postion: "职员"
                },
                {
                    adName: "王一",
                    adId: 110003,
                    password: 12333,
                    department: "管理部",
                    postion: "职员"
                }
            ],
            server: 180
        }
    ],
    service: [
        {
            serviceID: 1,
            style: "水电维修",
            Number: 120,
            onlineNumber: 40
        },
        {
            serviceID: 2,
            style: "家政",
            Number: 200,
            onlineNumber: 50
        },
        {
            serviceID: 3,
            style: "配送",
            Number: 220,
            onlineNumber: 100
        },
        {
            serviceID: 4,
            style: "老人陪护",
            Number: 90,
            onlineNumber: 30
        },
        {
            serviceID: 5,
            style: "社区医疗",
            Number: 125,
            onlineNumber: 40
        }
    ],
    dealedOrder: 1999,
    complainNumber: 100
} ]);
db.getCollection("platform").insert([ {
    _id: ObjectId("608782858e250000a60027e1"),
    serveLocation: [
        {
            localID: 10002,
            location: "宝贝小区社区服务站",
            Number: 100,
            administrator: [
                {
                    adName: "易烊",
                    adId: 110001,
                    password: 12333,
                    department: "财政部",
                    postion: "部长"
                },
                {
                    adName: "网元",
                    adId: 110001,
                    password: 12333,
                    department: "后勤部",
                    postion: "职员"
                },
                {
                    adName: "王一",
                    adId: 110003,
                    password: 12333,
                    department: "管理部",
                    postion: "职员"
                }
            ],
            server: 80
        }
    ],
    service: [
        {
            serviceID: 1,
            style: "水电维修",
            Number: 120,
            onlineNumber: 40
        },
        {
            serviceID: 2,
            style: "家政",
            Number: 200,
            onlineNumber: 50
        },
        {
            serviceID: 3,
            style: "配送",
            Number: 220,
            onlineNumber: 100
        }
    ],
    dealedOrder: 1999,
    complainNumber: 100
} ]);

// ----------------------------
// Collection structure for server
// ----------------------------
db.getCollection("server").drop();
db.createCollection("server");

// ----------------------------
// Documents of server
// ----------------------------
db.getCollection("server").insert([ {
    _id: ObjectId("607e2f8cb0370000f1004434"),
    id: 10001,
    serverName: "王五",
    password: 11111,
    TelephoneNumber: 123345,
    Style: "水电维修"
} ]);
db.getCollection("server").insert([ {
    _id: ObjectId("607e2f8cb0370000f1004435"),
    id: 10002,
    serverName: "张章",
    password: 11111,
    TelephoneNumber: 123345,
    Style: "家教"
} ]);
db.getCollection("server").insert([ {
    _id: ObjectId("607e2f8cb0370000f1004436"),
    id: 10003,
    serverName: "沈六",
    password: 11111,
    TelephoneNumber: 123345,
    Style: "配送"
} ]);

// ----------------------------
// Collection structure for system.views
// ----------------------------
db.getCollection("system.views").drop();
db.createCollection("system.views");

// ----------------------------
// Documents of system.views
// ----------------------------

// ----------------------------
// Collection structure for user
// ----------------------------
db.getCollection("user").drop();
db.createCollection("user");

// ----------------------------
// Documents of user
// ----------------------------
db.getCollection("user").insert([ {
    _id: ObjectId("6087776c8e250000a60027dd"),
    Username: "张三",
    passward: "123456",
    Sex: "男",
    Address: "幸福小区101",
    TelephoneNummber: 1234,
    order: [
        {
            orderID: 10001,
            serverID: 10001,
            service: "水电维修",
            Price: "100元",
            Content: "师傅服务热情",
            serveLocation: "幸福小区社区服务站",
            Time: "2021/2/20"
        },
        {
            orderID: 10002,
            serverID: 10003,
            service: "家教",
            Price: "200元",
            Content: "师傅服务热情",
            serveLocation: "幸福小区社区服务站",
            Time: "2021/3/20"
        }
    ]
} ]);
