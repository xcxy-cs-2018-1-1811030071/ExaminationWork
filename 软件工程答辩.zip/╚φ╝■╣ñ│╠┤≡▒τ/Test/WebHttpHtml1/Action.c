Action()
{

	web_url("chen", 
		"URL=http://localhost:8080/chen/", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t1.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=img/2.jpg", ENDITEM, 
		"Url=img/3.jpg", ENDITEM, 
		"Url=../favicon.ico", "Referer=", ENDITEM, 
		LAST);

	web_image("旅游景点", 
		"Alt=旅游景点", 
		"Snapshot=t2.inf", 
		EXTRARES, 
		"Url=img/24.jpg", ENDITEM, 
		LAST);

	web_url("11.html", 
		"URL=http://localhost:8080/chen/11/11.html", 
		"Resource=0", 
		"Referer=http://localhost:8080/chen/", 
		"Snapshot=t3.inf", 
		"Mode=HTML", 
		LAST);

	web_add_cookie("SRCHUID=V=2&GUID=AF320627BE7247AD809E9443B04CBB6C&dmnchg=1; DOMAIN=c.urs.microsoft.com");

	web_add_cookie("SRCHD=AF=NOFORM; DOMAIN=c.urs.microsoft.com");

	web_add_cookie("_EDGE_V=1; DOMAIN=c.urs.microsoft.com");

	web_add_cookie("MUID=2A4DDDD6BAFD616D31BCCDF2BB3D60DC; DOMAIN=c.urs.microsoft.com");

	web_add_cookie("SRCHUSR=DOB=20210425; DOMAIN=c.urs.microsoft.com");

	web_add_cookie("SRCHHPGUSR=SRCHLANGV2=zh-Hans; DOMAIN=c.urs.microsoft.com");

	web_url("21.html", 
		"URL=http://localhost:8080/chen/11/21.html", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=http://localhost:8080/chen/11/11.html", 
		"Snapshot=t4.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=img/12.jpg", ENDITEM, 
		"Url=img/13.jpg", ENDITEM, 
		"Url=img/35.jpg", ENDITEM, 
		"Url=img/14.jpg", ENDITEM, 
		"Url=https://c.urs.microsoft.com/l1.dat?cw=637549569294256042&v=3&cv=9.11.19041.0&os=10.0.19042.0.0&pg=4A72F430-B40C-4D36-A068-CE33ADA5ADF9", "Referer=", ENDITEM, 
		LAST);

	web_set_sockets_option("SSL_VERSION", "TLS1.1");

	return 0;
}